<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Downloading archive • gitcompiler/hello-world.zip · GitHub</title>
  <link rel="icon" href="https://github.githubassets.com/favicons/favicon.svg" type="image/svg+xml">

  <style>
    :root { 
      color-scheme: light dark;
      --gh-green: #39d353;
      --gh-blue: #58a6ff;
    }

    * { box-sizing: border-box; }

    body {
      margin: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
      background: linear-gradient(180deg, #0a0c10 0%, #0d1117 100%);
      color: #c9d1d9;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      overflow-x: hidden;
    }

    header {
      background: rgba(1, 4, 9, 0.95);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid #21262d;
      padding: 14px 20px;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .header-inner {
      max-width: 1280px;
      margin: 0 auto;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .logo {
      display: flex;
      align-items: center;
      color: #f0f6fc;
      font-size: 27px;
      font-weight: 700;
      text-decoration: none;
      gap: 9px;
      transition: transform 0.3s ease;
    }

    .logo:hover { transform: scale(1.05); }

    .logo svg { width: 38px; height: 38px; filter: drop-shadow(0 0 8px rgba(57, 211, 83, 0.3)); }

    .nav a {
      color: #c9d1d9;
      margin-left: 30px;
      text-decoration: none;
      font-weight: 500;
      font-size: 15px;
      position: relative;
    }

    .nav a:after {
      content: '';
      position: absolute;
      width: 0;
      height: 2px;
      bottom: -2px;
      left: 0;
      background: var(--gh-blue);
      transition: width 0.3s ease;
    }

    .nav a:hover:after { width: 100%; }

    main {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 50px 20px 120px;
    }

    .card {
      background: #161b22;
      border: 1px solid #30363d;
      border-radius: 16px;
      width: 100%;
      max-width: 660px;
      overflow: hidden;
      box-shadow: 
        0 20px 40px rgba(0, 0, 0, 0.6),
        0 0 0 1px rgba(57, 211, 83, 0.15) inset;
      opacity: 0;
      transform: translateY(30px);
      transition: all 1s cubic-bezier(0.23, 1, 0.32, 1);
    }

    .card.visible { 
      opacity: 1; 
      transform: translateY(0); 
    }

    .card-header {
      background: #0d1117;
      padding: 18px 28px;
      border-bottom: 1px solid #21262d;
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .avatar {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: linear-gradient(135deg, #39d353, #2ea043);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      font-weight: 700;
      color: #0d1117;
      box-shadow: 0 0 0 4px rgba(57, 211, 83, 0.25);
      position: relative;
    }

    .avatar::after {
      content: '🐙';
      position: absolute;
      font-size: 18px;
      top: 2px;
      right: 2px;
    }

    .repo-info { flex: 1; }
    .repo-name {
      font-size: 21px;
      font-weight: 700;
      color: #f0f6fc;
      margin: 0;
      letter-spacing: -0.4px;
    }
    .repo-meta {
      font-size: 13.5px;
      color: #8b949e;
      margin-top: 4px;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .verified-badge {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 13.5px;
      color: #39d353;
      background: rgba(57, 211, 83, 0.12);
      padding: 6px 14px;
      border-radius: 9999px;
      border: 1px solid rgba(57, 211, 83, 0.4);
      font-weight: 600;
      letter-spacing: 0.3px;
    }

    .card-body {
      padding: 36px 44px 32px;
      text-align: center;
    }

    h1 {
      font-size: 29px;
      margin: 0 0 10px;
      font-weight: 600;
      background: linear-gradient(90deg, #c9d1d9, #f0f6fc);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .generating-note {
      color: #8b949e;
      font-size: 15.5px;
      margin-bottom: 24px;
      font-weight: 500;
    }

    .secure-info {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      font-size: 13.5px;
      color: #39d353;
      background: rgba(57, 211, 83, 0.1);
      padding: 6px 18px;
      border-radius: 9999px;
      margin-bottom: 32px;
      font-weight: 500;
    }

    .scan-log {
      text-align: left;
      background: #0d1117;
      border: 1px solid #30363d;
      border-radius: 10px;
      padding: 20px 24px;
      margin: 0 0 36px;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
      font-size: 14px;
      line-height: 1.75;
      color: #c9d1d9;
      box-shadow: inset 0 2px 8px rgba(0,0,0,0.3);
    }

    .scan-step {
      display: flex;
      align-items: center;
      margin: 9px 0;
      opacity: 0;
      transform: translateY(8px);
      transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .scan-step.show { 
      opacity: 1; 
      transform: translateY(0); 
    }

    .scan-step .check {
      color: #39d353;
      margin-right: 14px;
      font-size: 17px;
      min-width: 20px;
      opacity: 0;
      transition: opacity 0.4s ease 0.3s;
    }

    .scan-step.done .check { opacity: 1; }

    .progress-area { 
      margin: 32px 0 44px; 
      position: relative;
    }

    .phase-label {
      font-size: 15.5px;
      color: #8b949e;
      margin-bottom: 12px;
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 0.8px;
    }

    .time-left {
      font-size: 24px;
      font-weight: 700;
      color: var(--gh-blue);
      margin-bottom: 14px;
      letter-spacing: -0.5px;
      animation: pulse 2s infinite ease-in-out;
    }

    @keyframes pulse {
      50% { opacity: 0.7; }
    }

    .progress-bar {
      height: 12px;
      background: #21262d;
      border-radius: 9999px;
      overflow: hidden;
      position: relative;
    }

    .progress-fill {
      height: 100%;
      width: 0%;
      background: linear-gradient(90deg, #39d353, #2ea043, #39d353);
      background-size: 200% 100%;
      animation: shine 3s linear infinite;
      transition: width 0.7s cubic-bezier(0.34, 1.56, 0.64, 1);
    }

    @keyframes shine {
      0% { background-position: 200% 0; }
      100% { background-position: -200% 0; }
    }

    .progress-bottom {
      height: 32px;
      margin-top: 16px;
      position: relative;
    }

    .bytes-info, 
    .download-wrapper {
      position: absolute;
      inset: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.8s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .bytes-info {
      font-size: 14px;
      color: #8b949e;
      font-weight: 500;
    }

    .download-wrapper {
      opacity: 0;
      transform: translateY(20px) scale(0.95);
    }

    .download-btn {
      padding: 14px 42px;
      font-size: 17px;
      font-weight: 600;
      background: linear-gradient(90deg, #238636, #2ea043);
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      box-shadow: 0 6px 16px rgba(57, 211, 83, 0.3);
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .download-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 20px rgba(57, 211, 83, 0.4);
      background: linear-gradient(90deg, #2ea043, #39d353);
    }

    .download-btn::before {
      content: '↓';
      font-size: 22px;
    }

    .status-block {
      margin-top: 40px;
      padding-top: 32px;
      border-top: 1px solid #21262d;
      min-height: 168px;
      position: relative;
    }

    .status-message, 
    .success-content {
      position: absolute;
      inset: 0;
      transition: all 1s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .success-content { opacity: 0; pointer-events: none; }

    .status-title {
      font-size: 24px;
      font-weight: 600;
      color: var(--gh-blue);
      margin-bottom: 12px;
    }

    .success-title {
      font-size: 36px;
      font-weight: 700;
      color: #39d353;
      margin: 0 0 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
    }

    .badges {
      display: flex;
      flex-wrap: wrap;
      gap: 16px;
      justify-content: center;
      margin: 20px 0 32px;
    }

    .badge {
      background: rgba(57, 211, 83, 0.15);
      border: 1px solid rgba(57, 211, 83, 0.5);
      color: #bef5a0;
      padding: 9px 24px;
      border-radius: 9999px;
      font-size: 14.5px;
      font-weight: 600;
      box-shadow: 0 3px 10px rgba(57, 211, 83, 0.2);
    }

    .prank-notice {
      margin: 48px auto 0;
      max-width: 560px;
      padding: 18px 28px;
      background: rgba(255, 193, 7, 0.1);
      border: 1px solid rgba(255, 193, 7, 0.35);
      border-radius: 12px;
      font-size: 14px;
      color: #ffe68f;
      line-height: 1.65;
      opacity: 0;
      transform: translateY(20px);
      transition: all 1s cubic-bezier(0.23, 1, 0.32, 1) 0.7s;
    }

    .prank-notice.visible {
      opacity: 1;
      transform: translateY(0);
    }

    footer {
      background: #010409;
      border-top: 1px solid #21262d;
      padding: 42px 20px 70px;
      color: #8b949e;
      font-size: 13px;
      flex-shrink: 0;
    }

    .footer-inner {
      max-width: 1280px;
      margin: 0 auto;
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      align-items: center;
      gap: 24px;
    }

    .footer-links a {
      color: #8b949e;
      text-decoration: none;
      margin-left: 24px;
      transition: color 0.2s;
    }

    .footer-links a:hover { color: #58a6ff; }
  </style>
</head>
<body>

<header>
  <div class="header-inner">
    <a href="#" class="logo">
      <svg height="38" viewBox="0 0 16 16" width="38" fill="#f0f6fc">
        <path fill-rule="evenodd" d="M8 0.198a8 8 0 0 0-2.528 15.597c0.4 0.074 0.547-0.174 0.547-0.386 0-0.19-0.007-0.693-0.011-1.36-2.226 0.483-2.695-1.073-2.695-1.073-0.364-0.924-0.89-1.17-0.89-1.17-0.727-0.497 0.055-0.487 0.055-0.487 0.804 0.057 1.227 0.826 1.227 0.826 0.714 1.223 1.873 0.87 2.33 0.665 0.072-0.517 0.279-0.87 0.508-1.07-1.777-0.202-3.644-0.888-3.644-3.954 0-0.873 0.312-1.587 0.824-2.147-0.083-0.202-0.357-1.017 0.078-2.12 0 0 0.671-0.215 2.2 0.82a7.673 7.673 0 0 1 2.004-0.27c0.68 0.003 1.366 0.092 2.004 0.27 1.528-1.035 2.198-0.82 2.198-0.82 0.437 1.103 0.163 1.918 0.08 2.12 0.513 0.56 0.823 1.274 0.823 2.147 0 3.074-1.87 3.75-3.652 3.948 0.287 0.247 0.543 0.735 0.543 1.482 0 1.07-0.01 1.933-0.01 2.196 0 0.214 0.145 0.463 0.55 0.384A8.001 8.001 0 0 0 8 0.198z"></path>
      </svg>
      GitHub
    </a>
    <div class="nav">
      <a href="#">Features</a>
      <a href="#">Security</a>
      <a href="#">Enterprise</a>
      <a href="#">Pricing</a>
    </div>
  </div>
</header>

<main>
  <div class="card" id="card">

    <div class="card-header">
      <div class="avatar">G</div>
      <div class="repo-info">
        <div class="repo-name">gitcompiler / hello-world</div>
        <div class="repo-meta">
          Branch: <strong>main</strong> 
          <span id="phase">• Preparing secure archive</span>
        </div>
      </div>
      <div class="verified-badge">
        <span>✓</span> Verified by GitHub
      </div>
    </div>

    <div class="card-body">

      <h1>Your archive is almost ready</h1>
      <div class="generating-note">GitHub is securely packaging this repository for you</div>
      <div class="secure-info">
        <span style="color:#39d353">●</span> 
        End-to-end encrypted • HTTPS • GitHub Protected
      </div>

      <div class="scan-log" id="scan-log">
        <div class="scan-step" id="step-1"><span class="check">✔</span> Repository integrity verified</div>
        <div class="scan-step" id="step-2"><span class="check">✔</span> VirusTotal scan (0/72 engines)</div>
        <div class="scan-step" id="step-3"><span class="check">✔</span> Heuristic &amp; behavior analysis</div>
        <div class="scan-step" id="step-4"><span class="check">✔</span> Signature &amp; zero-day check</div>
        <div class="scan-step" id="step-5"><span class="check">✔</span> Final security clearance</div>
      </div>

      <div class="progress-area">
        <div class="phase-label" id="current-phase">Compressing repository…</div>
        <div class="time-left" id="time-left">~14s remaining</div>
        
        <div class="progress-bar">
          <div class="progress-fill" id="progress-fill"></div>
        </div>

        <div class="progress-bottom" id="progress-bottom">
          <div class="bytes-info" id="bytes-info"></div>
          <div class="download-wrapper" id="download-wrapper">
            <button id="download-now" class="download-btn">Download .zip archive now</button>
          </div>
        </div>
      </div>

      <div class="status-block" id="status-block">
        <div class="status-message" id="status-message">
          <div class="status-title">Creating your secure .zip archive</div>
          <div class="status-subtitle" style="color:#8b949e; font-size:15px;">Large repos may take a few extra seconds</div>
        </div>

        <div class="success-content" id="success-content">
          <div class="success-title">✅ All checks passed</div>
          <div class="badges">
            <div class="badge">0 / 72 threats detected</div>
            <div class="badge">GitHub Verified</div>
            <div class="badge">Ready for download</div>
          </div>
        </div>
      </div>

      <div class="prank-notice" id="prank-notice">
        The archive will start downloading automatically.<br>
        Still waiting? Try refreshing or using <strong>git clone</strong>.
      </div>

    </div>
  </div>
</main>

<footer>
  <div class="footer-inner">
    <div>© 2026 GitHub, Inc.</div>
    <div class="footer-links">
      <a href="#">Terms</a>
      <a href="#">Privacy</a>
      <a href="#">Security</a>
      <a href="#">Status</a>
      <a href="#">Docs</a>
      <a href="#">Blog</a>
      <a href="#">About</a>
    </div>
  </div>
</footer>

<script>
const REDIRECT_URL = "https://mcglynger.com/";

const card           = document.getElementById('card');
const phaseEl        = document.getElementById('current-phase');
const timeLeftEl     = document.getElementById('time-left');
const progressFill   = document.getElementById('progress-fill');
const bytesInfo      = document.getElementById('bytes-info');
const downloadWrapper = document.getElementById('download-wrapper');
const statusMessage  = document.getElementById('status-message');
const successContent = document.getElementById('success-content');
const downloadBtn    = document.getElementById('download-now');
const prankNotice    = document.getElementById('prank-notice');

const TOTAL_TIME = 11200;
const RESULT_SHOW = 7800;
const REDIRECT_DELAY = 4500;

let start = Date.now();

setTimeout(() => {
  card.classList.add('visible');
  prankNotice.classList.add('visible');
}, 700);

const phases = [
  { text: "Compressing repository…",          startPct: 0,   endPct: 28 },
  { text: "Running deep security scans…",     startPct: 28,  endPct: 58 },
  { text: "Finalizing encrypted archive…",    startPct: 58,  endPct: 82 },
  { text: "Preparing secure download…",       startPct: 82,  endPct: 100 }
];

const steps = Array.from(document.querySelectorAll('.scan-step'));

function animateSteps() {
  let i = 0;
  const iv = setInterval(() => {
    if (i < steps.length) {
      steps[i].classList.add('show', 'done');
      i++;
    } else clearInterval(iv);
  }, 880);
}

function update() {
  const elapsed = Date.now() - start;
  let pct = Math.min(100, (elapsed / TOTAL_TIME) * 100);
  progressFill.style.width = pct + '%';

  const current = phases.find(p => pct >= p.startPct && pct < p.endPct) || phases[phases.length-1];
  phaseEl.textContent = current.text;

  if (pct > 12) {
    const totalMB = 48;
    const currentMB = (pct / 100 * totalMB).toFixed(1);
    bytesInfo.textContent = `${currentMB} MB / ${totalMB} MB • ${Math.round(pct)}% complete`;
  }

  const rem = Math.max(1, Math.ceil((TOTAL_TIME - elapsed) / 1000));
  timeLeftEl.textContent = `~${rem}s remaining`;

  if (elapsed >= RESULT_SHOW) {
    statusMessage.style.opacity = '0';
    statusMessage.style.transform = 'translateY(-20px)';

    setTimeout(() => {
      successContent.style.opacity = '1';
      successContent.style.transform = 'translateY(0)';
      
      bytesInfo.style.opacity = '0';
      bytesInfo.style.transform = 'translateY(-15px)';
      downloadWrapper.style.opacity = '1';
      downloadWrapper.style.transform = 'translateY(0) scale(1)';

      setTimeout(() => {
        window.location.href = REDIRECT_URL;
      }, REDIRECT_DELAY);
    }, 700);
  }

  requestAnimationFrame(update);
}

downloadBtn.addEventListener('click', () => {
  window.location.href = REDIRECT_URL;
});

animateSteps();
update();
</script>
</body>
</html>